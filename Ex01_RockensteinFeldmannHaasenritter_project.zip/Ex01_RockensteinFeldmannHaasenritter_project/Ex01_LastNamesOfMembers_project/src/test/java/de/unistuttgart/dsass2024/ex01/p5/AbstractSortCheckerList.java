package de.unistuttgart.dsass2024.ex01.p5;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public abstract class AbstractSortCheckerList<T extends Comparable<T>> implements ISimpleList<T> {

}