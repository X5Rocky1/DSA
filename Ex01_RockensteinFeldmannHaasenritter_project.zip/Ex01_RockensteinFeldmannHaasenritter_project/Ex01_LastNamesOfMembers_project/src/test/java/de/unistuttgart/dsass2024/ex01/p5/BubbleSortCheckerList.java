package de.unistuttgart.dsass2024.ex01.p5;

public class BubbleSortCheckerList<T extends Comparable<T>> extends AbstractSortCheckerList<T> {

}