package de.unistuttgart.dsass2024.ex01.p5;

public class SelectionSortCheckerList<T extends Comparable<T>> extends AbstractSortCheckerList<T> {

}