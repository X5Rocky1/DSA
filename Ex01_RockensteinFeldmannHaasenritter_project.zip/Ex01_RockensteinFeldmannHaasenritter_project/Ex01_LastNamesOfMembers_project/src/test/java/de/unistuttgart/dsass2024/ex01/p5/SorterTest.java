package de.unistuttgart.dsass2024.ex01.p5;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Test;

public class SorterTest {

}