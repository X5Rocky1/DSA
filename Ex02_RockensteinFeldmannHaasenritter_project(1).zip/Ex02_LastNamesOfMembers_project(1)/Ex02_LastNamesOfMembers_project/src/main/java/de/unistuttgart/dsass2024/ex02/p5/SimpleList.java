package de.unistuttgart.dsass2024.ex02.p5;

public class SimpleList<T extends Comparable<T>> implements ISimpleList<T> {

	 private ISimpleListNode<T> head;
	    private int size;

	    public SimpleList() {
	        this.head = null;
	        this.size = 0;
	    }
    @Override
    public int getSize() {
    	return size;

    }

    @Override
    public void prepend(T element) {
    	if (element == null) {
    		throw new IllegalArgumentException ("Element must exist!");	
    	}
    	
    	ISimpleListNode<T> newNode = new SimpleListNode<>(element);
        newNode.setNext(head);
        head = newNode;
        size++;
    }

    @Override
    public T getElement(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }
        ISimpleListNode<T> current = head;
        for (int i = 0; i < index; i++) {
            current = current.getNext();
        }
        return current.getElement();

    }

    @Override
    public void sort() {
    	
    	
    	 boolean sorted;
    	    ISimpleListNode<T> current;
    	    ISimpleListNode<T> last = null;

    	    do {
    	        sorted = true;
    	        current = head;

    	        while (current.getNext() != last) {
    	            if (current.getElement().compareTo(current.getNext().getElement()) > 0) {
    	                T temp = current.getElement();
    	                current.setElement(current.getNext().getElement());
    	                current.getNext().setElement(temp);
    	                sorted = false;
    	            }
    	            current = current.getNext();
    	        }
    	        last = current;
    	    } while (!sorted);
    	

    }

}