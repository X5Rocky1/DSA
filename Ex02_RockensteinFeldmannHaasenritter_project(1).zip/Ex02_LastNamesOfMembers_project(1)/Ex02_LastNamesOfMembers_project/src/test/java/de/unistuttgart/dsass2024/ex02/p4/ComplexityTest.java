package de.unistuttgart.dsass2024.ex02.p4;

import static org.junit.Assert.*;
import org.junit.*;

public class ComplexityTest {

}