package de.unistuttgart.dsass2024.ex02.p5;

public class SimpleList<T extends Comparable<T>> implements ISimpleList<T> {


    @Override
    public int getSize() {

    }

    @Override
    public void prepend(T element) {

    }

    @Override
    public T getElement(int index) {

    }

    @Override
    public void sort() {

    }

}